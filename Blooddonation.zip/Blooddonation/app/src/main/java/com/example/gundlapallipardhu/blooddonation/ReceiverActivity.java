package com.example.gundlapallipardhu.blooddonation;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReceiverActivity extends AppCompatActivity{
   private Button hpage;
   public TextView in;
   private TextView info;
   FirebaseDatabase fd=FirebaseDatabase.getInstance();
   DatabaseReference dr=fd.getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receiver);

        hpage=(Button)findViewById(R.id.btnhome);
        hpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent=new Intent(ReceiverActivity.this,MainActivity.class);
                startActivity(Intent);

            }
        });
       final String  x=getIntent().getExtras().getString("bloodgroup");
        System.out.println("&&&&&&&&&&   &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&^%%%%%%%$123");
        System.out.println(x);
        Toast.makeText(getApplicationContext(),x,Toast.LENGTH_LONG).show();
        info=(TextView)findViewById(R.id.view);
        dr.child(x).addValueEventListener(new ValueEventListener() {

            @Override

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int h=0;
                System.out.println("&&&&&&&&&&   &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&^%%%%%%%$");
                for(DataSnapshot templateSnapshot : dataSnapshot.getChildren()){
                    System.out.println("&&&&&&&&&&   &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&^%%%%%%%$"+x);

                    for(DataSnapshot snap :templateSnapshot.getChildren()){
                        String model = (String) snap.getValue();
                        info.append(model+"\n");
                        h++;
                        if(h==8){
                            info.append("\n");
                            System.out.println("&&&&&&&&&&  " +model+" &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&^%%%%%%%$");
                            h=0;
                        }
                        System.out.println(model.toString()+"&&&&&&******");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

            }
}
