package com.example.gundlapallipardhu.blooddonation;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

class data
{
    String name;
    String bg;
    String number;
    String address;
    String age;
    String email;
    String gender;
    String weight;

    public data(String name, String bg, String number, String address, String age, String email, String gender, String weight) {
        this.name = name;
        this.bg = bg;
        this.number = number;
        this.address = address;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.weight = weight;
    }

   public String toString()
   {
       return name+" "+bg+" "+number+" "+address+" "+age+" "+email+" "+gender+" "+weight;
   }

}

public class DonorActivity extends AppCompatActivity {
    private EditText name;
    private EditText bloodgroup;
    private EditText phonenumber;
    private EditText age;
    private EditText weight;
    private EditText email;
    private EditText address;
    private EditText gender;
    private Button next;


    FirebaseDatabase db;
    DatabaseReference dr;
    data d;
    long id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor);
        name = (EditText) findViewById(R.id.etname);
        bloodgroup = (EditText) findViewById(R.id.etbg);
        phonenumber = (EditText) findViewById(R.id.etnum);
        address = (EditText) findViewById(R.id.etaddress);
        age = (EditText) findViewById(R.id.etage);
        email = (EditText) findViewById(R.id.etmail);
        gender = (EditText) findViewById(R.id.etgender);
        weight = (EditText) findViewById(R.id.etweight);
        next = (Button) findViewById(R.id.cont);


        db = FirebaseDatabase.getInstance();
        dr = db.getInstance().getReference();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {


                    String bd = bloodgroup.getText().toString();
                    //String blood;

                    //String blood = bd.toLowerCase();
                    switch (bd) {
                        case "A+":
                            dr = db.getReference("A+");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();

                            break;
                        case "A-":
                            dr = db.getReference("A-");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;

                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "B+":
                            dr = db.getReference("B+");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "B-":
                            dr = db.getReference("B-");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "AB+":
                            dr = db.getReference("AB+");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "AB-":
                            dr = db.getReference("AB-");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "O+":
                            dr = db.getReference("O+");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id++)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted.. ", Toast.LENGTH_LONG).show();
                            break;
                        case "O-":
                            dr = db.getReference("O-");
                            d = new data(name.getText().toString(), bloodgroup.getText().toString(), phonenumber.getText().toString(), address.getText().toString(), age.getText().toString(), email.getText().toString(), gender.getText().toString(), weight.getText().toString());
                            id = id + 1;
                            dr.child(String.valueOf(id)).setValue(d);
                            Toast.makeText(DonorActivity.this, d + "..data inserted..  ", Toast.LENGTH_LONG).show();
                            break;


                    }

                }
            }

            private boolean validate() {
                Boolean result = false;

                String name1 = name.getText().toString();
                String Bgroup = bloodgroup.getText().toString();
                String mobile = phonenumber.getText().toString();
                String mail = email.getText().toString();
                String addr = address.getText().toString();
                String ag = age.getText().toString();
                String wei = weight.getText().toString();
                String gend = gender.getText().toString();
                int a = Integer.parseInt(ag);
                int b = Integer.parseInt(wei);

                if (name1.isEmpty() || Bgroup.isEmpty() || mobile.isEmpty() || mail.isEmpty() ||
                        addr.isEmpty() || ag.isEmpty() || wei.isEmpty() || gend.isEmpty()) {
                    Toast.makeText(DonorActivity.this, "please fill all the details", Toast.LENGTH_LONG).show();

                }
                else if (a < 17) {
                    Toast.makeText(DonorActivity.this, "your age is not valid for blood donation", Toast.LENGTH_LONG).show();
                }

                else if (a > 60) {
                    Toast.makeText(DonorActivity.this, "your age is not valid for blood donation", Toast.LENGTH_LONG).show();
                }
                else if (b < 50) {
                    Toast.makeText(DonorActivity.this, "your weight is not valid for blood donation", Toast.LENGTH_LONG).show();
                } else {
                    result = true;
                }
                return result;

            }

        });
    }
}

