package com.example.gundlapallipardhu.blooddonation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private TextView donor;
    private TextView select;
    private Button apos;
    private Button aneg;
    private Button bpos;
    private Button bneg;
    private Button abpos;
    private Button abneg;
    private Button opos;
    private Button oneg;
    private Button exi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        donor=(TextView)findViewById(R.id.tvdonor);
        select=(TextView)findViewById(R.id.tvblood);
        apos=(Button)findViewById(R.id.ap);
        aneg=(Button)findViewById(R.id.an);
        bpos=(Button)findViewById(R.id.bp);
        bneg=(Button)findViewById(R.id.bn);
        abpos=(Button)findViewById(R.id.abp);
        abneg=(Button)findViewById(R.id.abn);
        opos=(Button)findViewById(R.id.op);
          oneg=(Button)findViewById(R.id.on);
          exi=(Button)findViewById(R.id.btnexit);


          donor.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                     Intent Intent=new Intent(MainActivity.this,DonorActivity.class);

                     startActivity(Intent);

              }
          });
          apos.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent intent1=new Intent(MainActivity.this,ReceiverActivity.class);
                  intent1.putExtra("bloodgroup",apos.getText().toString());
                  startActivity(intent1);

              }
          });

        aneg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(MainActivity.this,ReceiverActivity.class);
                intent2.putExtra("bloodgroup",aneg.getText().toString());
                startActivity(intent2);
            }
        });
        bpos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(MainActivity.this,ReceiverActivity.class);
                intent3.putExtra("bloodgroup",bpos.getText().toString());
                startActivity(intent3);
            }
        });


        bneg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4=new Intent(MainActivity.this,ReceiverActivity.class);
                intent4.putExtra("bloodgroup",bneg.getText().toString());
                startActivity(intent4);
            }
        });
        abpos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5=new Intent(MainActivity.this,ReceiverActivity.class);
                intent5.putExtra("bloodgroup",abpos.getText().toString());
                startActivity(intent5);
            }
        });
        abneg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent6=new Intent(MainActivity.this,ReceiverActivity.class);
                intent6.putExtra("bloodgroup",abneg.getText().toString());
                startActivity(intent6);
            }
        });
        opos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent7=new Intent(MainActivity.this,ReceiverActivity.class);
                intent7.putExtra("bloodgroup",opos.getText().toString());
                startActivity(intent7);
            }
        });
        oneg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent8=new Intent(MainActivity.this,ReceiverActivity.class);
                intent8.putExtra("bloodgroup",oneg.getText().toString());
                startActivity(intent8);
            }
        });
        exi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
