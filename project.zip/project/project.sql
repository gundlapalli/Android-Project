--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


--
-- Name: fun(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fun() RETURNS trigger
    LANGUAGE plpgsql
    AS $$  
begin                                                                     
     select * from person where age > 40; 
return new;                                                
      end; 
$$;


ALTER FUNCTION public.fun() OWNER TO postgres;

--
-- Name: high(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.high() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ begin                                                                                             
 insert into Serves                                                                                  
  select price from Serves where price < 13;                                                         
   return new;                                                                                        
   end;                                                                                                
  $$;


ALTER FUNCTION public.high() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: finances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.finances (
    fin_ticker character varying NOT NULL,
    total_revenue character varying,
    cost_of_revenue character varying,
    income_before_tax character varying,
    net_income character varying
);


ALTER TABLE public.finances OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    sprof_ticker character varying NOT NULL,
    name character varying,
    address character varying,
    phonenum character varying,
    website character varying,
    sector character varying,
    industry character varying,
    full_time character varying,
    bus_summ character varying
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statistics (
    stat_ticker character varying NOT NULL,
    marketcap character varying,
    enterprise_value character varying,
    return_on_assets character varying,
    total_cash character varying,
    operating_cash_flow character varying,
    levered_free_cash_flow character varying,
    total_debt character varying,
    current_ratio character varying,
    gross_profit character varying,
    proffit_margin character varying
);


ALTER TABLE public.statistics OWNER TO postgres;

--
-- Data for Name: finances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.finances (fin_ticker, total_revenue, cost_of_revenue, income_before_tax, net_income) FROM stdin;
FEYE	751,086	268,887	-299,059	-303,691
IRBT	883,911	438,114	76,366	50,964
TWTR	2,443,299	860,842	-95,418	-108,063
NXPI	9,256,000	4,634,000	1,789,000	2,215,000
NIO	-	13,562,000	-	-
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (sprof_ticker, name, address, phonenum, website, sector, industry, full_time, bus_summ) FROM stdin;
FEYE	FireEye, Inc.	601 McCarthy BoulevardMilpitas, CA 95035United States408-321-6300	408-321-6300	http://www.fireeye.com	Technology	Software - Application	2,960	\N
IRBT	iRobot Corporation	8 Crosby DriveBedford, MA 01730United States781-430-3000	781-430-3000	http://www.irobot.com	Technology	Consumer Electronics	1,003	\N
TWTR	Twitter, Inc.	1355 Market StreetSuite 900San Francisco, CA 94103United States415-222-9670	415-222-9670	http://www.twitter.com	Technology	Internet Content & Information	3,800	\N
NXPI	NXP Semiconductors N.V.	High Tech Campus 60Eindhoven 5656 AGNetherlands31 40 272 9999	31 40 272 9999	http://www.nxp.com	Technology	Semiconductors	30,200	\N
NIO	NIO Inc.	Building 20No. 56 AnTuo Road Jiading DistrictShanghai 201804China86 21 6908 3306	86 21 6908 3306	http://www.nio.io	Consumer Cyclical	Auto Manufacturers	3,774	\N
NOK	Nokia Corporation	Karaportti 3Espoo 02610Finland358 1044 88000	358 1044 88000	http://www.nokia.com	Technology	Communication Equipment		\N
\.


--
-- Data for Name: statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statistics (stat_ticker, marketcap, enterprise_value, return_on_assets, total_cash, operating_cash_flow, levered_free_cash_flow, total_debt, current_ratio, gross_profit, proffit_margin) FROM stdin;
FEYE	3.57B	3.44B	-35.87%	-5.34%	482.2M	1.09B	950.94M	2.02	20.37M	89.6M
IRBT	2.48B	2.33B	6.52%	9.51%	445.8M	135.12M	N/A	2.59	65.51M	436.88k
TWTR	25.92B	22.8B	36.35%	2.70%	1.58B	5.96B	2.71B	4.61	1.21B	629.18M
NXPI	27.32B	27.3B	28.38%	2.36%	4.62B	1.94B	6.36B	1.22	4.38B	2.71B
NIO	8.62B	8B	0.00%	N/A	N/A	N/A	N/A	2.56	N/A	N/A
NOK	34.09B	33.78B	-1.51%	1.76%	9B	N/A	N/A	1.29	N/A	N/A
\.


--
-- Name: finances finances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.finances
    ADD CONSTRAINT finances_pkey PRIMARY KEY (fin_ticker);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (sprof_ticker);


--
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (stat_ticker);


--
-- PostgreSQL database dump complete
--

