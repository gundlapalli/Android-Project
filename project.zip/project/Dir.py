import requests
import csv
from bs4 import BeautifulSoup
import os

page = requests.get('https://finance.yahoo.com/trending-tickers')
soup = BeautifulSoup(page.text, 'html.parser')
class tickers:
	
	stock_symbol= soup.find(class_='yfinlist-table W(100%) BdB Bdc($tableBorderGray)')
	stock_symbol_items = stock_symbol.find_all('a')

	for symbol in stock_symbol_items:
		os.stat('tickers')
		if not ' react-empty:' in symbol.contents[0]:
			symbols = symbol.contents[0] 
			try:
				os.makedirs(os.path.join('tickers',symbols))
			except:
				print("already exists")
				
			page1=requests.get('https://finance.yahoo.com/quote/'+symbols+'/profile?p='+symbols)
			soup1=BeautifulSoup(page1.text,'html.parser')
			f1=open('tickers/'+symbols+'/profile.html',"w")
			f1.write(str(soup1.encode("utf-8")))
			
			page2=requests.get('https://finance.yahoo.com/quote/'+symbols+'/financials?p='+symbols)
			soup2=BeautifulSoup(page2.text,'html.parser')
			f2=open('tickers/'+symbols+'/financials.html',"w")
			f2.write(str(soup2.encode("utf-8")))
			
			page3=requests.get('https://finance.yahoo.com/quote/'+symbols+'/key-statistics?p='+symbols)
			soup3=BeautifulSoup(page3.text,'html.parser')
			f3=open('tickers/'+symbols+'/statistics.html',"w")
			f3.write(str(soup3.encode("utf-8")))
			
			
			page4=requests.get('https://finance.yahoo.com/quote/'+symbols+'?p='+symbols)
			soup4=BeautifulSoup(page4.text,'html.parser')
			f4=open('tickers/'+symbols+'/summary.html',"w")
			f4.write(str(soup4.encode("utf-8")))