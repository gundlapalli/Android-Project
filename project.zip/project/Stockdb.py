import requests
import os
from bs4 import BeautifulSoup
'''def profile(url,r):
    str='\n'
    f=open('COMPANIES/'+y[0]+'/profile.txt',"w")
    page1=requests.get(url)
    soup1=BeautifulSoup(page1.text,"html.parser")
    containers1=soup1.find(class_='asset-profile-container')
    items1=containers1.find('h3')
    itemsadd=containers1.find('p')
    itemssecInd=soup1.find_all('span',{'class':'Fw(600)'})
    print(items1.text)
    str2=items1.text+str
    f.write(str2)
    str3=itemsadd.text
    v=str3.find('http')
    f.write(str3[v:]+str)
    f.write(str3[:v]+str)
    for i in itemssecInd:
        f.write(i.text+str)
    containers2=soup1.find_all('tr',{'class':'C(black) BdB Bdc($finLightGray) H(36px)'})
    for i in containers2:
        t=i.find_all('td')
        for j in t:
            print(j.text)
            f.write(j.text+str)
def financials(url,r):
    str='\n'
    count=0
    f=open('COMPANIES/'+y[0]+'/financials.txt',"w")
    page2=requests.get(url)
    soup2=BeautifulSoup(page2.text,"html.parser")
    containers3=soup2.find_all('tr',{'class':'Bdbw(1px) Bdbc($c-fuji-grey-c) Bdbs(s) H(36px)'})
    for i in containers3:
        s=i.find_all('td')
        for j in s:
            sr=j.text
            if(ord(sr[0])>64):
                sp=j.text
                if(sp=='Net Income'):
                    count+=1
            if(sp=='Revenue' or sp=='Total Revenue' or sp=='Cost of Revenue' or sp=='Income Before Tax' or (sp=='Net Income' and count==2)):
                print(j.text)
                f.write(j.text+str)'''
def keystatistics(url,r):
	str='\n'
	f=open('COMPANIES/'+y[0]+'/statistics.txt','w')
	page=requests.get(url)
	print(url)
	soup2=BeautifulSoup(page.text,'html.parser')
	containers3=soup2.find_all('table',{'class':'table-qsp-stats Mt(10px)'})
	for i in containers3:
		s=i.find_all('tr')
	for j in s:
		#print(j)
		for k in j:
			r=k.text
			print("hello"+r)
			if(ord(r[0])>64 and r[0]!='N'):
				f.write(k.text+str)
				#s1=k.text
				#print(s1)
				#if( s1=='Market Cap (intraday) 5' or s1=='Enterprise Value 3' or s1=='Return on Assets (ttm)' or s1=='Total Cash (mrq)' or s1=='Operating Cash Flow (ttm)' or s1=='Levered Free Cash Flow (ttm)'or s1=='Total Debt (mrq)' or s1=='Current Ratio (mrq)' or s1=='Gross Profit (ttm)' or s1=='Profit Margin '):
				#print(k.text)

    
f=open('tickers1.txt','w')
page=requests.get('https://finance.yahoo.com/trending-tickers')
soup=BeautifulSoup(page.text,'html.parser')
containers=soup.find_all('a',{'class':'Fw(b)'})
list=[]
x=''
for i in containers:
	str=i.text+"::"+i.get('title')+"\n"
	f.write(str)
f=open('tickers.txt','r')
str="COMPANIES"
try:
	os.mkdir(str)
except FileExistsError:
	print("already exists")
for i in f:
	x=i.strip()
	y=x.split('::')
	try:
		os.makedirs(os.path.join(str,y[0]))
	except FileExistsError:
		print(' ')
		#strurl1='https://finance.yahoo.com/'+'quote/'+y[0]+'/financials?p='+y[0]
		#financials(strurl1,y[0])
		#strurl='https://finance.yahoo.com/'+'quote/'+y[0]+'/profile?p='+y[0]
		#profile(strurl,y[0])
		strurl2='https://finance.yahoo.com/'+'quote/'+y[0]+'/key-statistics?p='+y[0]
		keystatistics(strurl2,y[0])