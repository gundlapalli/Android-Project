import psycopg2

conn = psycopg2.connect("user=postgres password=root")
current = conn.cursor()
#drops the table if it exists in the database
current.execute("DROP TABLE IF EXISTS statistics")
current.execute("DROP TABLE IF EXISTS profiles")
current.execute("DROP TABLE IF EXISTS finances")
#creating a table in the database
StatisticsTable = current.execute("CREATE TABLE statistics (stat_ticker varchar PRIMARY KEY,marketcap  varchar,enterprise_value varchar,return_on_assets varchar,total_cash varchar ,operating_cash_flow varchar ,levered_free_cash_flow varchar ,total_debt varchar ,current_ratio varchar ,gross_profit varchar ,proffit_margin varchar );")
ProfilesTable = current.execute("CREATE TABLE profiles (sprof_ticker varchar PRIMARY KEY,name  varchar,Address  varchar,phonenum varchar,website  varchar ,sector  varchar ,industry  varchar ,full_time  varchar ,bus_summ varchar );")
FinancesTable = current.execute("CREATE TABLE finances (Fin_ticker  varchar PRIMARY KEY,Total_Revenue  varchar,Cost_of_Revenue  varchar,Income_Before_Tax varchar,Net_Income  varchar);")

conn.commit()
conn.close()
current.close()
