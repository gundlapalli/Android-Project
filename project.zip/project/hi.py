import re
import psycopg2
class Query:
#removing stopwords


#connecting to DATABASE
	conn = psycopg2.connect(user="postgres",password="root")
	print("data base connect:")
	def isstopword():
		conn = psycopg2.connect(user="postgres",password="root")
		current = conn.cursor()
		f=open('stopwords.txt','r')
		inp=input("enter your query")
		stopword=[]
		list1=list(f)
		uword=[]
		for word in list1:
			word=word.replace('"','')
			stopword.append(word.strip())
		#print(stopword)
		list2=inp.split(" ")
		for y in list2:
			if y not in stopword:
				uword.append(y)
		#print(uword)		
#generating query
		dict1={'stat_ticker':'statisticstable','marketcap':'statisticstable','enterprise_value':'statisticstable','return_on_assets':'statisticstable','total_cash':'statisticstable','operating_cash_flow':'statisticstable','levered_free_cash_flow':'statisticstable','total_debt':'statisticstable','current_ratio':'statisticstable','gross_profit':'statisticstable','proffit_margin':'statisticstable','sprof_ticker':'profilestable','name':'profilestable','address':'profilestable','phonenum':'profilestable','website':'profilestable','sector':'profilestable','industry':'profilestable','full_time':'profilestable','bus_summ':'profilestable','fin_ticker':'financestable','total_revenue':'financestable','cost_of_revenue':'financestable','income_before_tax':'financestable','net_income':'financestable'}
		comName=[]
		tickerToInsert= []
		with open("Tickers1.txt") as fil:
			for line in fil:
				n=line.split("::")
				tickerToInsert.append(n[0].rstrip())
				comName.append(n[0].rstrip())
		#print(comName)
		query=""
		ques=['what','where','howmuch','None','which']
		mq=""
		name=""
		col="def"
		for x in uword:
			if x in ques:
				query="Select"
		#print(query)
		for x in dict1:
			#print(x)
			#print(uword)
			if x in uword:
				#print(uword)
				col=x
				#print(query+" "+x)
				#print(dict1[x])
				if(dict1[x]=='financestable'):
					name="fin_ticker"
				elif(dict1[x]=='statisticstable'):
					name="stat_ticker"
				elif(dict1[x]=='profilestable'):
					name="sprof_ticker"
				else:
					name=" "
		print(name)
		mq=query+" "+col+" from "+dict1[x]+" where "+name+"="
		print(mq)
		for word in uword:
			if word in comName:
				query=word
				mq=mq+"'"+word+"'"
				print(query)
				print(mq)
		print(mq)
		current.execute(mq)
		rows=current.fetchall()
		print(rows)
		
	conn.commit()
	conn.close()
	isstopword()	
	