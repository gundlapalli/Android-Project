import re
import psycopg2

class Query:
#removing stopwords


#connecting to DATABASE
	conn = psycopg2.connect(user="postgres",password="root")
	print("data base connect:")
	def isstopword():
		conn = psycopg2.connect(user="postgres",password="root")
		current = conn.cursor()
		f=open('stopwords.txt','r')
		#taking input from user
		inp=input("enter your query")
		stopword=[]
		list1=list(f)
		uword=[]
		for word in list1:
			word=word.replace('"','')
			stopword.append(word.strip())
		#print(stopword)
		list2=inp.split(" ")
		for y in list2:
			if y not in stopword:
				uword.append(y)
		#print(uword)		
#generating query
		dict1={'stat_ticker':'statistics','marketcap':'statistics','enterprise_value':'statistics','return_on_assets':'statistics','total_cash':'statistics','operating_cash_flow':'statistics','levered_free_cash_flow':'statistics','total_debt':'statistics','current_ratio':'statistics','gross_profit':'statistics','proffit_margin':'statistics','sprof_ticker':'profiles','name':'profiles','address':'profiles','phonenum':'profiles','website':'profiles','sector':'profiles','industry':'profiles','full_time':'profiles','bus_summ':'profiles','fin_ticker':'finances','total_revenue':'finances','cost_of_revenue':'finances','income_before_tax':'finances','net_income':'finances'}
		comName=[]
		tickerToInsert= []
		with open("tickers.txt") as fil:
			for line in fil:
				n=line.split("::")
				tickerToInsert.append(n[0].rstrip())
				comName.append(n[0].rstrip())
		#print(comName)
		query=""
		ques=['what','where','how','much','None','which']
		mq=""
		name=""
		col="def"
		for x in uword:
			if x in ques:
				query="Select"
		#print(query)
		for x in dict1:
			#print(x)
			#print(uword)
			if x in uword:
				print(uword)
				col=x
				print(query+" "+x)
				print(dict1[x])
				if(dict1[col]=='finances'):
					name="fin_ticker"
					at='finances'
				elif(dict1[col]=='statistics'):
					name="stat_ticker"
					at='statistics'
				elif(dict1[col]=='profiles'):
					name="sprof_ticker"
					at='profiles'
				else:
					name=" "
					at=''
		#print(col)
		#print(name)
		#print(at)
		mq=query+" "+col+" from "+at+" where "+name+"="
		#print(mq)
		for word in uword:
			if word in comName:
				query=word
				mq=mq+"'"+word+"'"
				#print(query)
				#print(mq)
		print(mq)
		current.execute(mq)
		rows=current.fetchall()
		print(rows)
		
	conn.commit()
	conn.close()
	isstopword()	
	