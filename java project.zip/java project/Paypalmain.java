package in.msitprogram.jntuh.paypal;

import java.io.IOException;
import java.util.Scanner;

public class Paypalmain {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		Scanner s = new Scanner(System.in);
		System.out.println("------------------WELCOME TO PAYPAL-------------------");

		while (true)

		{
			System.out.println("choose\n1.Signup\n2.login\n3.display");
			int choice = s.nextInt();
			switch (choice) {
			case 1:
				Signupdetails s1 = new Signupdetails();
				s1.details();
				System.out.println("choose \n1. for personal account\n2.for the student account\n3.for the employee account");
				int  a = s.nextInt();
				switch (a) {
				case 1:
					System.out.println("personal member details");
					personalaccount p = new personalaccount();
					System.out.println(p.toString());
					break;
				case 2:
					System.out.println("student");
					break;
				case 3:
					System.out.println("student");
					break;

				}
				
				
			case 2:
				Logindetails l1 = new Logindetails();
				l1.info();
				break;
			case 3:
				Signupdetails s11 = new Signupdetails();
				s11.display();
				break;
			
			}

		}

	}

}




































