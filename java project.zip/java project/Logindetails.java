package in.msitprogram.jntuh.paypal;

import java.io.FileInputStream;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Logindetails {
	public void info() {
		Scanner s = new Scanner(System.in);
		FileInputStream f = null;
		ObjectInputStream i = null;

		ArrayList<Userdetails> a = new ArrayList<Userdetails>();
		try {
			f = new FileInputStream("proje.txt");
			i = new ObjectInputStream(f);
			a = (ArrayList<Userdetails>) i.readObject();
		} catch (ClassNotFoundException | IOException e) {

			e.printStackTrace();
		}

		Userdetails ud = new Userdetails();
		System.out.println("enter Email ID :");
		ud.email = s.next();
		System.out.println("enter pasword :");
		ud.password = s.next();

		for (int i1 = 0; i1 < a.size(); i1++) {
			Userdetails u = a.get(i1);

			if ((u.email).equals(ud.email) && (u.password).equals(ud.password)) {
				
				activate a1 = new activate();
				String str = a1.getToken(6);
				System.out.println(str);

				System.out.println("enter Activation code :");
				String ac = s.next();
				if (str.equals(ac)) {
					System.out.println("loggedin Successfully");
					makeTransaction(ud.email);

				} else {
					System.out.println("wrong activation code");

				}
				
			}
				
			}
		
		}
	public void makeTransaction(String eml) {
		 
		Scanner s1=new Scanner(System.in);
		System.out.println("choose \n1. for add funds\n2.for withdraw money\n3.for send money\n4.for the request money\n 5. for the display balence");
		Userdetails ud = new Userdetails();
		
		int k = s1.nextInt();
		personalaccount p = new personalaccount();
		transaction tr=new transaction();
		
		switch (k) {
		case 1:
			
			
			System.out.printf("enter adding amount");
			  double amount=s1.nextDouble();
			  System.out.println(amount);
			p.addfunds(amount);
			break;
		case 2:
			System.out.println("enter the withdraw amount");
			 amount=s1.nextDouble();
			p.withdrawfunds(amount);
			
			
			break;
		case 3:
			System.out.println("enter how much money do you want to send");
			 amount=s1.nextDouble();
			 p.sendmoney(amount);
			break;
			
		case 4:
			System.out.println("enter how much money do you want");
			amount=s1.nextDouble();
			p.requestmoney(amount);
			break;
	
		
		}
		System.out.println("inside transaction");
		 FileInputStream file;
		   ObjectInputStream in;
		   ArrayList<Userdetails>  al = null;
		try {
			file = new FileInputStream("proje.txt");
			 in = new ObjectInputStream(file); 
			 al=(ArrayList<Userdetails>) in.readObject(); 
			   in.close(); 
	         file.close(); 
	           
		} catch (Exception e) {
			// TODO Auto-g/enerated catch block
			e.printStackTrace();
		} 

	     for(int i=0;i<al.size();i++) {
	    	   	
	  	  
	  	   if(al.get(i).email.equals(eml)) 
	  	   {
	  		 
	  		 System.out.println("===============================");
	  		 System.out.println(" Account Holder details ");
	  		 System.out.println(" Email is "+al.get(i).email);
	  		 System.out.println(" Name is "+al.get(i).userName);
	  		 System.out.println("= Account Balnce "+al.get(i).balence1);
	  		  tr.getCurrentTimeUsingDate();
	  		 
	  		//System.out.println("= Transactions "+ al.get(i).transactions);
	  		 System.out.println("===============================");
	  		//break;
	  	   }
	  	   
	     }

	}
	}
	
      
