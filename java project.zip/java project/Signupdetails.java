package in.msitprogram.jntuh.paypal;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

class Userdetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String email;
	public String password;
	public String userName;
	public String phno;
	public String address;
	public String balence1;
    personalaccount de;
   
	public String toString() {
		return "[User Name :" + userName + "\nemail :" + email + "\nphno :" + phno + "\nAddress :" + address + "\nbalence:"+ balence1 +"]";
	}
}

public class Signupdetails {
	public void details() throws IOException, ClassNotFoundException {
		ArrayList<Userdetails> a = new ArrayList<Userdetails>();
		FileOutputStream file1 = null;
		ObjectOutputStream out = null;
		Scanner s = new Scanner(System.in);
		Userdetails ud1 = new Userdetails();
		try {
			//file1 = new FileOutputStream("proje.txt");
			 //out = new ObjectOutputStream(file1);
			FileInputStream file = new FileInputStream("proje.txt");
			ObjectInputStream in = new ObjectInputStream(file);
			a = (ArrayList<Userdetails>) in.readObject();
			file1 = new FileOutputStream("proje.txt");
			out = new ObjectOutputStream(file1);

			System.out.println("Enter E-Mail Id: ");
			ud1.email = s.next();
			int c = 0;
			for (int k = 0; k < a.size(); k++) {
				Userdetails user = a.get(k);

				if ((user.email).equals(ud1.email)) {
					c++;
					
					break;
				}
			}
			if (c > 0) {
				System.out.println("Already present");
				c = 0;
			} else {
				System.out.println("Enter password:");
				ud1.password = s.next();
				System.out.println("Enter user name:");
				ud1.userName = s.next();
				System.out.println("Enter ph no:");
				ud1.phno = s.next();
				System.out.println("Enter Address:");
				ud1.address = s.next();
				a.add(ud1);
				out.writeObject(a);

				in.close();
				file.close();

				out.close();
				file.close();
			}
		}

		catch (EOFException ex) {
			System.out.println("Enter E-Mail Id: ");
			ud1.email = s.next();

			System.out.println("Enter password:");
			ud1.password = s.next();
			System.out.println("Enter user name:");
			ud1.userName = s.next();
			System.out.println("Enter ph no:");
			ud1.phno = s.next();
			System.out.println("Enter Address:");
			ud1.address = s.next();
			a.add(ud1);
			out.writeObject(a);
			out.close();
			file1.close();

			System.out.println("No user found");
		}

	}

	
	public void display() throws ClassNotFoundException, IOException {
		FileInputStream file = new FileInputStream("proje.txt");
		ObjectInputStream in = new ObjectInputStream(file);
		ArrayList<Userdetails> a = new ArrayList<Userdetails>();
		a = (ArrayList<Userdetails>) in.readObject();
		for (int i = 0; i < a.size(); i++) {
			System.out.println(a.get(i));
		}
	}
}
