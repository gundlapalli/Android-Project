package in.msitprogram.jntuh.paypal;

import java.sql.Date;

public class transaction {
   
	
	

	public void getCurrentTimeUsingDate() {
		Date date=new Date(0);
		System.out.println(date);
		
	}
	
}
