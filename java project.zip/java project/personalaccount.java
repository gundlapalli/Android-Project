package in.msitprogram.jntuh.paypal;

import java.util.ArrayList;
import java.util.Scanner;

public class personalaccount {
	ArrayList<Userdetails> a = new ArrayList<Userdetails>();
	Scanner s = new Scanner(System.in);
	double  balence1=0;
	//int  amount;
	double  balence;

	public void withdrawfunds(double  amount) {
		
		// Scanner s=new Scanner(System.in);

		if (amount <= balence) {
			balence1 = balence1- amount;
			System.out.println("balence in your account" +balence1);
			
		} else {
			System.out.println("insuffiecint funds in your account");
		}

	}

	public void requestmoney(double amount) {
		
	}

	public void sendmoney(double amount) {
		
		Userdetails ud = new Userdetails();
		System.out.println("enter the email address of the person");
		ud.email=s.next();
		for (int i1 = 0; i1 < a.size(); i1++) {
			Userdetails u = a.get(i1);
        System.out.println("hello");
			if ((u.email).equals(ud.email))
			{
				if(amount<=balence1)
				{
					balence1=balence1-amount;
					System.out.println("remaining balence in account "+balence1);
					
				}
				else
				{
					System.out.println("insufficient funds in your account");
				}
			}
			else {
				System.out.println("amount transaction not possible");
			}
		
		}

	}

	public void addfunds(double balence)

	{

		balence1 = balence1 + balence;

		System.out.printf("balence in your account  " + balence1);

	}

	
}